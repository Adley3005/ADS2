package com.farmaceutica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmaceuticaBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
