package com.farmaceutica.config;

public class SwaggerConfig {
}
