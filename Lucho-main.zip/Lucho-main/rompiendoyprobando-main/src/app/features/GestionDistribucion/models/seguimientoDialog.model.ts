// --------------------------------------------------------
// MODELO - DIALOG DATA (para el Overlay de Info Lote)
// --------------------------------------------------------
export interface InfoLoteDialogData {
    idLote: number;
}