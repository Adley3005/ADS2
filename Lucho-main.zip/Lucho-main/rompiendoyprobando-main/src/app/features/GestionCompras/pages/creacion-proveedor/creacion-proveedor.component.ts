import { Component } from '@angular/core';

@Component({
  selector: 'app-creacion-proveedor.component',
  standalone: false,
  templateUrl: './creacion-proveedor.component.html',
  styleUrl: './creacion-proveedor.component.css',
})
export class CreacionProveedorComponent {

}
