import { Component } from '@angular/core';

@Component({
  selector: 'app-popup-resumen-historial.component',
  standalone: false,
  templateUrl: './popup-resumen-historial.component.html',
  styleUrl: './popup-resumen-historial.component.css',
})
export class PopupResumenHistorialComponent {

}
