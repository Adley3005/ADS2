import { Component } from '@angular/core';

@Component({
  selector: 'app-headerbar',
  standalone: false,
  templateUrl: './headerbar.html',
  styleUrl: './headerbar.css',
})
export class Headerbar {

}
