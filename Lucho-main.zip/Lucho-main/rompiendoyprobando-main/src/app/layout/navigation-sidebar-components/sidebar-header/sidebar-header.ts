import { Component } from '@angular/core';

@Component({
  selector: 'app-sidebar-header',
  standalone: false,
  templateUrl: './sidebar-header.html',
  styleUrl: './sidebar-header.css',
})
export class SidebarHeader {

}
